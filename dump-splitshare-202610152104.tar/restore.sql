--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg120+1)
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE splitshare;
--
-- Name: splitshare; Type: DATABASE; Schema: -; Owner: module_platform
--

CREATE DATABASE splitshare WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE splitshare OWNER TO module_platform;

\unrestrict (null)
\connect splitshare
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: splitshare; Type: SCHEMA; Schema: -; Owner: module_platform
--

CREATE SCHEMA splitshare;


ALTER SCHEMA splitshare OWNER TO module_platform;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: EmailVerificationTokens; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."EmailVerificationTokens" (
    "Id" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "TokenHash" text NOT NULL,
    "ExpiresAt" timestamp with time zone NOT NULL,
    "UsedAt" timestamp with time zone
);


ALTER TABLE splitshare."EmailVerificationTokens" OWNER TO module_platform;

--
-- Name: ExpenseAudits; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."ExpenseAudits" (
    "Id" uuid NOT NULL,
    "ExpenseId" uuid NOT NULL,
    "ActorId" uuid NOT NULL,
    "DiffJson" text NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."ExpenseAudits" OWNER TO module_platform;

--
-- Name: ExpenseComments; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."ExpenseComments" (
    "Id" uuid NOT NULL,
    "ExpenseId" uuid NOT NULL,
    "AuthorId" uuid NOT NULL,
    "Body" character varying(1000) NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."ExpenseComments" OWNER TO module_platform;

--
-- Name: ExpenseGuests; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."ExpenseGuests" (
    "Id" uuid NOT NULL,
    "ExpenseId" uuid NOT NULL,
    "CoveredByUserId" uuid NOT NULL,
    "Label" character varying(50) NOT NULL,
    "ShareCents" bigint NOT NULL
);


ALTER TABLE splitshare."ExpenseGuests" OWNER TO module_platform;

--
-- Name: ExpenseImages; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."ExpenseImages" (
    "Id" uuid NOT NULL,
    "ExpenseId" uuid NOT NULL,
    "StorageKey" character varying(512) NOT NULL,
    "Mime" character varying(64) NOT NULL,
    "SizeBytes" bigint NOT NULL,
    "UploadedBy" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."ExpenseImages" OWNER TO module_platform;

--
-- Name: ExpenseSplits; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."ExpenseSplits" (
    "ExpenseId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "ShareCents" bigint NOT NULL,
    "ExactCents" bigint,
    "Percent" numeric(5,2),
    "Shares" integer
);


ALTER TABLE splitshare."ExpenseSplits" OWNER TO module_platform;

--
-- Name: Expenses; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."Expenses" (
    "Id" uuid NOT NULL,
    "GroupId" uuid NOT NULL,
    "Title" character varying(100) NOT NULL,
    "Description" character varying(1000),
    "AmountCents" bigint NOT NULL,
    "PayerId" uuid NOT NULL,
    "SplitType" integer NOT NULL,
    "Status" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL,
    "Version" integer NOT NULL,
    "DeletedAt" timestamp with time zone,
    "Category" character varying(32) DEFAULT ''::character varying NOT NULL,
    "FeeCents" bigint DEFAULT 0 NOT NULL,
    "FxRate" numeric(18,8),
    "OrigAmountCents" bigint,
    "OrigCurrency" character varying(3),
    "SpentAt" timestamp with time zone DEFAULT '-infinity'::timestamp with time zone NOT NULL,
    "TaxCents" bigint DEFAULT 0 NOT NULL,
    "TipCents" bigint DEFAULT 0 NOT NULL
);


ALTER TABLE splitshare."Expenses" OWNER TO module_platform;

--
-- Name: GroupMembers; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."GroupMembers" (
    "GroupId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "Role" text NOT NULL,
    "JoinedAt" timestamp with time zone NOT NULL,
    "DepositPaid" boolean DEFAULT false NOT NULL
);


ALTER TABLE splitshare."GroupMembers" OWNER TO module_platform;

--
-- Name: Groups; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."Groups" (
    "Id" uuid NOT NULL,
    "Name" character varying(50) NOT NULL,
    "Currency" character varying(3) NOT NULL,
    "InviteToken" text NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "DeletedAt" timestamp with time zone,
    "BudgetAlertPct" integer DEFAULT 0 NOT NULL,
    "BudgetCents" bigint,
    "FlatFeeCents" bigint,
    "Mode" character varying(16) DEFAULT ''::character varying NOT NULL,
    "ShareToken" text
);


ALTER TABLE splitshare."Groups" OWNER TO module_platform;

--
-- Name: IdempotencyKeys; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."IdempotencyKeys" (
    "Key" text NOT NULL,
    "Endpoint" text NOT NULL,
    "ResponseStatus" integer NOT NULL,
    "ResponseJson" text NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."IdempotencyKeys" OWNER TO module_platform;

--
-- Name: MembershipArchives; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."MembershipArchives" (
    "GroupId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "RemovedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."MembershipArchives" OWNER TO module_platform;

--
-- Name: Nudges; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."Nudges" (
    "Id" uuid NOT NULL,
    "GroupId" uuid NOT NULL,
    "FromUserId" uuid NOT NULL,
    "ToUserId" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."Nudges" OWNER TO module_platform;

--
-- Name: PasswordResetTokens; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."PasswordResetTokens" (
    "Id" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "TokenHash" text NOT NULL,
    "ExpiresAt" timestamp with time zone NOT NULL,
    "UsedAt" timestamp with time zone
);


ALTER TABLE splitshare."PasswordResetTokens" OWNER TO module_platform;

--
-- Name: PaymentHandles; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."PaymentHandles" (
    "Id" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "Label" character varying(64) NOT NULL,
    "Details" character varying(280) NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."PaymentHandles" OWNER TO module_platform;

--
-- Name: PaymentProofs; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."PaymentProofs" (
    "Id" uuid NOT NULL,
    "PaymentId" uuid NOT NULL,
    "StorageKey" character varying(512) NOT NULL,
    "Mime" character varying(64) NOT NULL,
    "SizeBytes" bigint NOT NULL,
    "UploadedBy" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."PaymentProofs" OWNER TO module_platform;

--
-- Name: Payments; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."Payments" (
    "Id" uuid NOT NULL,
    "GroupId" uuid NOT NULL,
    "FromUserId" uuid NOT NULL,
    "ToUserId" uuid NOT NULL,
    "AmountCents" bigint NOT NULL,
    "Method" character varying(16) NOT NULL,
    "Note" character varying(280),
    "CreatedBy" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "ReversedAt" timestamp with time zone,
    "Status" integer NOT NULL,
    "ProofRef" character varying(140)
);


ALTER TABLE splitshare."Payments" OWNER TO module_platform;

--
-- Name: PendingInvites; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."PendingInvites" (
    "Id" uuid NOT NULL,
    "GroupId" uuid NOT NULL,
    "Email" text NOT NULL,
    "InvitedBy" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "ConsumedAt" timestamp with time zone
);


ALTER TABLE splitshare."PendingInvites" OWNER TO module_platform;

--
-- Name: RecurringRules; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."RecurringRules" (
    "Id" uuid NOT NULL,
    "GroupId" uuid NOT NULL,
    "Title" character varying(100) NOT NULL,
    "AmountCents" bigint NOT NULL,
    "SplitType" integer NOT NULL,
    "PayerId" uuid NOT NULL,
    "ParticipantIdsJson" text NOT NULL,
    "Frequency" character varying(16) NOT NULL,
    "NextRunAt" timestamp with time zone NOT NULL,
    "Active" boolean NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "LastRunAt" timestamp with time zone
);


ALTER TABLE splitshare."RecurringRules" OWNER TO module_platform;

--
-- Name: RefreshTokens; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."RefreshTokens" (
    "Id" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "TokenHash" text NOT NULL,
    "ExpiresAt" timestamp with time zone NOT NULL,
    "RevokedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE splitshare."RefreshTokens" OWNER TO module_platform;

--
-- Name: SettlementPlans; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."SettlementPlans" (
    "Id" uuid NOT NULL,
    "GroupId" uuid NOT NULL,
    "VersionSeq" integer NOT NULL,
    "ComputedAt" timestamp with time zone NOT NULL,
    "InputsHash" character varying(128) NOT NULL,
    "TransfersJson" text NOT NULL,
    "ExplanationJson" text NOT NULL
);


ALTER TABLE splitshare."SettlementPlans" OWNER TO module_platform;

--
-- Name: Users; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."Users" (
    "Id" uuid NOT NULL,
    "DisplayName" character varying(50) NOT NULL,
    "Username" character varying(30) NOT NULL,
    "Email" character varying(320) NOT NULL,
    "Phone" text,
    "PasswordHash" text,
    "GoogleSub" text,
    "CreatedAt" timestamp with time zone NOT NULL,
    "EmailVerifiedAt" timestamp with time zone,
    "FailedLoginAttempts" integer NOT NULL,
    "LockedUntilUtc" timestamp with time zone
);


ALTER TABLE splitshare."Users" OWNER TO module_platform;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: splitshare; Owner: module_platform
--

CREATE TABLE splitshare."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE splitshare."__EFMigrationsHistory" OWNER TO module_platform;

--
-- Data for Name: EmailVerificationTokens; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."EmailVerificationTokens" ("Id", "UserId", "TokenHash", "ExpiresAt", "UsedAt") FROM stdin;
\.
COPY splitshare."EmailVerificationTokens" ("Id", "UserId", "TokenHash", "ExpiresAt", "UsedAt") FROM '$$PATH$$/4472.dat';

--
-- Data for Name: ExpenseAudits; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."ExpenseAudits" ("Id", "ExpenseId", "ActorId", "DiffJson", "CreatedAt") FROM stdin;
\.
COPY splitshare."ExpenseAudits" ("Id", "ExpenseId", "ActorId", "DiffJson", "CreatedAt") FROM '$$PATH$$/4473.dat';

--
-- Data for Name: ExpenseComments; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."ExpenseComments" ("Id", "ExpenseId", "AuthorId", "Body", "CreatedAt") FROM stdin;
\.
COPY splitshare."ExpenseComments" ("Id", "ExpenseId", "AuthorId", "Body", "CreatedAt") FROM '$$PATH$$/4487.dat';

--
-- Data for Name: ExpenseGuests; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."ExpenseGuests" ("Id", "ExpenseId", "CoveredByUserId", "Label", "ShareCents") FROM stdin;
\.
COPY splitshare."ExpenseGuests" ("Id", "ExpenseId", "CoveredByUserId", "Label", "ShareCents") FROM '$$PATH$$/4488.dat';

--
-- Data for Name: ExpenseImages; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."ExpenseImages" ("Id", "ExpenseId", "StorageKey", "Mime", "SizeBytes", "UploadedBy", "CreatedAt") FROM stdin;
\.
COPY splitshare."ExpenseImages" ("Id", "ExpenseId", "StorageKey", "Mime", "SizeBytes", "UploadedBy", "CreatedAt") FROM '$$PATH$$/4484.dat';

--
-- Data for Name: ExpenseSplits; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."ExpenseSplits" ("ExpenseId", "UserId", "ShareCents", "ExactCents", "Percent", "Shares") FROM stdin;
\.
COPY splitshare."ExpenseSplits" ("ExpenseId", "UserId", "ShareCents", "ExactCents", "Percent", "Shares") FROM '$$PATH$$/4485.dat';

--
-- Data for Name: Expenses; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."Expenses" ("Id", "GroupId", "Title", "Description", "AmountCents", "PayerId", "SplitType", "Status", "CreatedBy", "CreatedAt", "UpdatedAt", "Version", "DeletedAt", "Category", "FeeCents", "FxRate", "OrigAmountCents", "OrigCurrency", "SpentAt", "TaxCents", "TipCents") FROM stdin;
\.
COPY splitshare."Expenses" ("Id", "GroupId", "Title", "Description", "AmountCents", "PayerId", "SplitType", "Status", "CreatedBy", "CreatedAt", "UpdatedAt", "Version", "DeletedAt", "Category", "FeeCents", "FxRate", "OrigAmountCents", "OrigCurrency", "SpentAt", "TaxCents", "TipCents") FROM '$$PATH$$/4474.dat';

--
-- Data for Name: GroupMembers; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."GroupMembers" ("GroupId", "UserId", "Role", "JoinedAt", "DepositPaid") FROM stdin;
\.
COPY splitshare."GroupMembers" ("GroupId", "UserId", "Role", "JoinedAt", "DepositPaid") FROM '$$PATH$$/4486.dat';

--
-- Data for Name: Groups; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."Groups" ("Id", "Name", "Currency", "InviteToken", "CreatedBy", "CreatedAt", "DeletedAt", "BudgetAlertPct", "BudgetCents", "FlatFeeCents", "Mode", "ShareToken") FROM stdin;
\.
COPY splitshare."Groups" ("Id", "Name", "Currency", "InviteToken", "CreatedBy", "CreatedAt", "DeletedAt", "BudgetAlertPct", "BudgetCents", "FlatFeeCents", "Mode", "ShareToken") FROM '$$PATH$$/4475.dat';

--
-- Data for Name: IdempotencyKeys; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."IdempotencyKeys" ("Key", "Endpoint", "ResponseStatus", "ResponseJson", "CreatedAt") FROM stdin;
\.
COPY splitshare."IdempotencyKeys" ("Key", "Endpoint", "ResponseStatus", "ResponseJson", "CreatedAt") FROM '$$PATH$$/4476.dat';

--
-- Data for Name: MembershipArchives; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."MembershipArchives" ("GroupId", "UserId", "RemovedAt") FROM stdin;
\.
COPY splitshare."MembershipArchives" ("GroupId", "UserId", "RemovedAt") FROM '$$PATH$$/4477.dat';

--
-- Data for Name: Nudges; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."Nudges" ("Id", "GroupId", "FromUserId", "ToUserId", "CreatedAt") FROM stdin;
\.
COPY splitshare."Nudges" ("Id", "GroupId", "FromUserId", "ToUserId", "CreatedAt") FROM '$$PATH$$/4489.dat';

--
-- Data for Name: PasswordResetTokens; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."PasswordResetTokens" ("Id", "UserId", "TokenHash", "ExpiresAt", "UsedAt") FROM stdin;
\.
COPY splitshare."PasswordResetTokens" ("Id", "UserId", "TokenHash", "ExpiresAt", "UsedAt") FROM '$$PATH$$/4478.dat';

--
-- Data for Name: PaymentHandles; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."PaymentHandles" ("Id", "UserId", "Label", "Details", "CreatedAt") FROM stdin;
\.
COPY splitshare."PaymentHandles" ("Id", "UserId", "Label", "Details", "CreatedAt") FROM '$$PATH$$/4490.dat';

--
-- Data for Name: PaymentProofs; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."PaymentProofs" ("Id", "PaymentId", "StorageKey", "Mime", "SizeBytes", "UploadedBy", "CreatedAt") FROM stdin;
\.
COPY splitshare."PaymentProofs" ("Id", "PaymentId", "StorageKey", "Mime", "SizeBytes", "UploadedBy", "CreatedAt") FROM '$$PATH$$/4491.dat';

--
-- Data for Name: Payments; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."Payments" ("Id", "GroupId", "FromUserId", "ToUserId", "AmountCents", "Method", "Note", "CreatedBy", "CreatedAt", "ReversedAt", "Status", "ProofRef") FROM stdin;
\.
COPY splitshare."Payments" ("Id", "GroupId", "FromUserId", "ToUserId", "AmountCents", "Method", "Note", "CreatedBy", "CreatedAt", "ReversedAt", "Status", "ProofRef") FROM '$$PATH$$/4479.dat';

--
-- Data for Name: PendingInvites; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."PendingInvites" ("Id", "GroupId", "Email", "InvitedBy", "CreatedAt", "ConsumedAt") FROM stdin;
\.
COPY splitshare."PendingInvites" ("Id", "GroupId", "Email", "InvitedBy", "CreatedAt", "ConsumedAt") FROM '$$PATH$$/4480.dat';

--
-- Data for Name: RecurringRules; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."RecurringRules" ("Id", "GroupId", "Title", "AmountCents", "SplitType", "PayerId", "ParticipantIdsJson", "Frequency", "NextRunAt", "Active", "CreatedBy", "CreatedAt", "LastRunAt") FROM stdin;
\.
COPY splitshare."RecurringRules" ("Id", "GroupId", "Title", "AmountCents", "SplitType", "PayerId", "ParticipantIdsJson", "Frequency", "NextRunAt", "Active", "CreatedBy", "CreatedAt", "LastRunAt") FROM '$$PATH$$/4492.dat';

--
-- Data for Name: RefreshTokens; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."RefreshTokens" ("Id", "UserId", "TokenHash", "ExpiresAt", "RevokedAt", "CreatedAt") FROM stdin;
\.
COPY splitshare."RefreshTokens" ("Id", "UserId", "TokenHash", "ExpiresAt", "RevokedAt", "CreatedAt") FROM '$$PATH$$/4481.dat';

--
-- Data for Name: SettlementPlans; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."SettlementPlans" ("Id", "GroupId", "VersionSeq", "ComputedAt", "InputsHash", "TransfersJson", "ExplanationJson") FROM stdin;
\.
COPY splitshare."SettlementPlans" ("Id", "GroupId", "VersionSeq", "ComputedAt", "InputsHash", "TransfersJson", "ExplanationJson") FROM '$$PATH$$/4482.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."Users" ("Id", "DisplayName", "Username", "Email", "Phone", "PasswordHash", "GoogleSub", "CreatedAt", "EmailVerifiedAt", "FailedLoginAttempts", "LockedUntilUtc") FROM stdin;
\.
COPY splitshare."Users" ("Id", "DisplayName", "Username", "Email", "Phone", "PasswordHash", "GoogleSub", "CreatedAt", "EmailVerifiedAt", "FailedLoginAttempts", "LockedUntilUtc") FROM '$$PATH$$/4483.dat';

--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: splitshare; Owner: module_platform
--

COPY splitshare."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.
COPY splitshare."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM '$$PATH$$/4471.dat';

--
-- Name: EmailVerificationTokens PK_EmailVerificationTokens; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."EmailVerificationTokens"
    ADD CONSTRAINT "PK_EmailVerificationTokens" PRIMARY KEY ("Id");


--
-- Name: ExpenseAudits PK_ExpenseAudits; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseAudits"
    ADD CONSTRAINT "PK_ExpenseAudits" PRIMARY KEY ("Id");


--
-- Name: ExpenseComments PK_ExpenseComments; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseComments"
    ADD CONSTRAINT "PK_ExpenseComments" PRIMARY KEY ("Id");


--
-- Name: ExpenseGuests PK_ExpenseGuests; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseGuests"
    ADD CONSTRAINT "PK_ExpenseGuests" PRIMARY KEY ("Id");


--
-- Name: ExpenseImages PK_ExpenseImages; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseImages"
    ADD CONSTRAINT "PK_ExpenseImages" PRIMARY KEY ("Id");


--
-- Name: ExpenseSplits PK_ExpenseSplits; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseSplits"
    ADD CONSTRAINT "PK_ExpenseSplits" PRIMARY KEY ("ExpenseId", "UserId");


--
-- Name: Expenses PK_Expenses; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."Expenses"
    ADD CONSTRAINT "PK_Expenses" PRIMARY KEY ("Id");


--
-- Name: GroupMembers PK_GroupMembers; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."GroupMembers"
    ADD CONSTRAINT "PK_GroupMembers" PRIMARY KEY ("GroupId", "UserId");


--
-- Name: Groups PK_Groups; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."Groups"
    ADD CONSTRAINT "PK_Groups" PRIMARY KEY ("Id");


--
-- Name: IdempotencyKeys PK_IdempotencyKeys; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."IdempotencyKeys"
    ADD CONSTRAINT "PK_IdempotencyKeys" PRIMARY KEY ("Key", "Endpoint");


--
-- Name: MembershipArchives PK_MembershipArchives; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."MembershipArchives"
    ADD CONSTRAINT "PK_MembershipArchives" PRIMARY KEY ("GroupId", "UserId");


--
-- Name: Nudges PK_Nudges; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."Nudges"
    ADD CONSTRAINT "PK_Nudges" PRIMARY KEY ("Id");


--
-- Name: PasswordResetTokens PK_PasswordResetTokens; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."PasswordResetTokens"
    ADD CONSTRAINT "PK_PasswordResetTokens" PRIMARY KEY ("Id");


--
-- Name: PaymentHandles PK_PaymentHandles; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."PaymentHandles"
    ADD CONSTRAINT "PK_PaymentHandles" PRIMARY KEY ("Id");


--
-- Name: PaymentProofs PK_PaymentProofs; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."PaymentProofs"
    ADD CONSTRAINT "PK_PaymentProofs" PRIMARY KEY ("Id");


--
-- Name: Payments PK_Payments; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."Payments"
    ADD CONSTRAINT "PK_Payments" PRIMARY KEY ("Id");


--
-- Name: PendingInvites PK_PendingInvites; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."PendingInvites"
    ADD CONSTRAINT "PK_PendingInvites" PRIMARY KEY ("Id");


--
-- Name: RecurringRules PK_RecurringRules; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."RecurringRules"
    ADD CONSTRAINT "PK_RecurringRules" PRIMARY KEY ("Id");


--
-- Name: RefreshTokens PK_RefreshTokens; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."RefreshTokens"
    ADD CONSTRAINT "PK_RefreshTokens" PRIMARY KEY ("Id");


--
-- Name: SettlementPlans PK_SettlementPlans; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."SettlementPlans"
    ADD CONSTRAINT "PK_SettlementPlans" PRIMARY KEY ("Id");


--
-- Name: Users PK_Users; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."Users"
    ADD CONSTRAINT "PK_Users" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: IX_EmailVerificationTokens_TokenHash; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_EmailVerificationTokens_TokenHash" ON splitshare."EmailVerificationTokens" USING btree ("TokenHash");


--
-- Name: IX_ExpenseAudits_ExpenseId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_ExpenseAudits_ExpenseId" ON splitshare."ExpenseAudits" USING btree ("ExpenseId");


--
-- Name: IX_ExpenseComments_ExpenseId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_ExpenseComments_ExpenseId" ON splitshare."ExpenseComments" USING btree ("ExpenseId");


--
-- Name: IX_ExpenseGuests_ExpenseId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_ExpenseGuests_ExpenseId" ON splitshare."ExpenseGuests" USING btree ("ExpenseId");


--
-- Name: IX_ExpenseImages_ExpenseId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_ExpenseImages_ExpenseId" ON splitshare."ExpenseImages" USING btree ("ExpenseId");


--
-- Name: IX_Expenses_GroupId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_Expenses_GroupId" ON splitshare."Expenses" USING btree ("GroupId");


--
-- Name: IX_Groups_InviteToken; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_Groups_InviteToken" ON splitshare."Groups" USING btree ("InviteToken");


--
-- Name: IX_Nudges_GroupId_FromUserId_ToUserId_CreatedAt; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_Nudges_GroupId_FromUserId_ToUserId_CreatedAt" ON splitshare."Nudges" USING btree ("GroupId", "FromUserId", "ToUserId", "CreatedAt");


--
-- Name: IX_PasswordResetTokens_TokenHash; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_PasswordResetTokens_TokenHash" ON splitshare."PasswordResetTokens" USING btree ("TokenHash");


--
-- Name: IX_PaymentHandles_UserId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_PaymentHandles_UserId" ON splitshare."PaymentHandles" USING btree ("UserId");


--
-- Name: IX_PaymentProofs_PaymentId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_PaymentProofs_PaymentId" ON splitshare."PaymentProofs" USING btree ("PaymentId");


--
-- Name: IX_Payments_GroupId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_Payments_GroupId" ON splitshare."Payments" USING btree ("GroupId");


--
-- Name: IX_PendingInvites_GroupId_Email; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_PendingInvites_GroupId_Email" ON splitshare."PendingInvites" USING btree ("GroupId", "Email");


--
-- Name: IX_RecurringRules_GroupId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_RecurringRules_GroupId" ON splitshare."RecurringRules" USING btree ("GroupId");


--
-- Name: IX_RefreshTokens_TokenHash; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_RefreshTokens_TokenHash" ON splitshare."RefreshTokens" USING btree ("TokenHash");


--
-- Name: IX_RefreshTokens_UserId; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE INDEX "IX_RefreshTokens_UserId" ON splitshare."RefreshTokens" USING btree ("UserId");


--
-- Name: IX_SettlementPlans_GroupId_VersionSeq; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_SettlementPlans_GroupId_VersionSeq" ON splitshare."SettlementPlans" USING btree ("GroupId", "VersionSeq");


--
-- Name: IX_Users_Email; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_Users_Email" ON splitshare."Users" USING btree ("Email");


--
-- Name: IX_Users_Username; Type: INDEX; Schema: splitshare; Owner: module_platform
--

CREATE UNIQUE INDEX "IX_Users_Username" ON splitshare."Users" USING btree ("Username");


--
-- Name: ExpenseGuests FK_ExpenseGuests_Expenses_ExpenseId; Type: FK CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseGuests"
    ADD CONSTRAINT "FK_ExpenseGuests_Expenses_ExpenseId" FOREIGN KEY ("ExpenseId") REFERENCES splitshare."Expenses"("Id") ON DELETE CASCADE;


--
-- Name: ExpenseImages FK_ExpenseImages_Expenses_ExpenseId; Type: FK CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseImages"
    ADD CONSTRAINT "FK_ExpenseImages_Expenses_ExpenseId" FOREIGN KEY ("ExpenseId") REFERENCES splitshare."Expenses"("Id") ON DELETE CASCADE;


--
-- Name: ExpenseSplits FK_ExpenseSplits_Expenses_ExpenseId; Type: FK CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."ExpenseSplits"
    ADD CONSTRAINT "FK_ExpenseSplits_Expenses_ExpenseId" FOREIGN KEY ("ExpenseId") REFERENCES splitshare."Expenses"("Id") ON DELETE CASCADE;


--
-- Name: GroupMembers FK_GroupMembers_Groups_GroupId; Type: FK CONSTRAINT; Schema: splitshare; Owner: module_platform
--

ALTER TABLE ONLY splitshare."GroupMembers"
    ADD CONSTRAINT "FK_GroupMembers_Groups_GroupId" FOREIGN KEY ("GroupId") REFERENCES splitshare."Groups"("Id") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

